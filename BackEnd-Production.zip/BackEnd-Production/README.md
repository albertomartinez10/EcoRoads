# BackEnd
BackEnd of the project. Done with NodeJS.
