module.exports = {
    AuthController: require('./authController'),
    UsersController: require('./usersController'),
    ChargePointsController: require('./chargePointsController'),
    sampleVehiclesController: require('./sampleVehiclesController'),
    ReportController: require('./reportController'),
    AchievementController: require('./achievementController'),
    ServiceController: require('./serviceController'),
    MsgController: require('./msgController'),
}
