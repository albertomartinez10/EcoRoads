const getAchievementById = require('./getAchievementById');
const getAllAchievements = require('./getAllAchievements');

module.exports = {
    getAchievementById: getAchievementById,
    getAllAchievements: getAllAchievements,
}
