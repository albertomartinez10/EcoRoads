const registerUser = require('./register');
const loginUser = require('./login');

module.exports = {
    registerUser,
    loginUser
}