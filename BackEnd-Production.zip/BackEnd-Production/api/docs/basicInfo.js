module.exports = {
    swagger: "2.0",
    info: {
        title: 'Eco Roads API',
        description: "API for Eco Roads backend",
        version: '1.0.0',
        contact: {
            name: 'Eco Roads',
            email: 'ecoroads@gmail.com',
            url: 'https://ecoroads.com'
        }
    }
}