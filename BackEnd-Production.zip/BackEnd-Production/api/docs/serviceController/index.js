const getClosest = require('./getClosest');
const getClosestAvailable = require('./getClosestAvailable');

module.exports = {
    getClosest: getClosest,
    getClosestAvailable: getClosestAvailable,
}