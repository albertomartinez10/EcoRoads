module.exports = {
    tags: [
        {
            name: "ChargePoints controller",
            description: "Controller for chargePoints",
        },
        {
            name: "User controller",
            description: "Controller for users",
        },
        {
            name: "Sample Vehicles Controller",
            description: "Controller for sample vehicles",
        },
        {
            name: "Service Controller",
            description: "Controller for services",
        },
        {
            name: "Achievement Controller",
            description: "Controller for achievements",
        },
        {
            name: "Message Controller",
            description: "Controller for messages",
        },
    ]
}