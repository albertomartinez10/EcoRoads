module.exports.authService = require('./auth.service');
module.exports.userService = require('./user.service');
module.exports.chargePointService = require('./chargePoint.service');
module.exports.sampleVehicleService = require('./sampleVehicle.service');
module.exports.socialMediaService = require('./socialMedia.service');
module.exports.reportService = require('./report.service');
module.exports.achievementService = require('./achievement.service');
module.exports.msgService = require('./msg.service');