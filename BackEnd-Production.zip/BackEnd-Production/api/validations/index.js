module.exports = {
    authValidation: require('./auth.validation'),
    sampleVehiclesValidation: require('./sampleVehicles.validation'), 
};